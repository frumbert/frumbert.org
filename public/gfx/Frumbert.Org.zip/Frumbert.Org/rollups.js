function getState(divname) {
    var state;
    if (document.all) {
        state=eval("document.all." + divname + ".style.display");
    }
    if (document.layers) {
        state=document.layers[divname].display;
    }
    if (document.getElementById && !document.all) {
        state=document.getElementById(divname).style.display
    }
    
    if (state.length > 0) {
        return state;
    } else {
        return 'none';
    }
}
function chgstate(divname) {
    var state;
    var today = new Date();
    var expires = new Date(today.getTime() + (365 * 86400000));
    if (getState(divname) == 'block') {
        state = 'none';
        if (divname.substring(0,3) != 'td_') {
            document.cookie = divname + '=1;expires='+expires.toGMTString();
        }
    } else {
        state = 'block';
        if (divname.substring(0,3) != 'td_') {
            document.cookie = divname + '=0;expires='+expires.toGMTString();
        }
        
    }
    if (document.all) { // IE
        eval("document.all." + divname + ".style.display=state");
    }
    if (document.layers) { // NS
        document.layers[divname].display = state;
    }
    if (document.getElementById && !document.all) {
        var test = document.getElementById(divname);
        test.style.display = state;
    }
   

}
function chknset(divName) {
    var current = getState(divName);
    if (current == 'none') {
        chgstate(divName);
    }
}
function setstate(divname,state) {
    if (document.all) { // IE
        eval("document.all." + divname + ".style.display=state");
    }                                                                                                                     
    if (document.layers) { // NS
        document.layers[divname].display = state;
    }
    if (document.getElementById && !document.all) {
        var test = document.getElementById(divname);
        test.style.display = state;
    }
}