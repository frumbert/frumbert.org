//	
//	provide SIMPLE functionality for mouse over alt tags - nothing fancy here.
//

document.write("<div style='background-color:#ffffe0; border:1px solid black; color:black; position:absolute; z-index:99; width:255px; padding:2px; font-size:xx-small; font-family:verdana,geneva,sans-serif; display:none;' id='alttagDiv'>&nbsp;</div>");

var over;
var ie5 = false;
var ns6 = (document.getElementById)? true:false;
var ie4 = (document.all)? true:false;
if (ie4) var docRoot = 'document.body';
if (ie4) {
	if ((navigator.userAgent.indexOf('MSIE 5') > 0) || (navigator.userAgent.indexOf('MSIE 6') > 0)) ie5 = true;
	if (ns6) ns6 = false;
}

document.onmousemove = mouseMove;
if (ie4) over = alttagDiv.style;
if (ns6) over = document.getElementById("alttagDiv");

var moveable = 0;
over.display = "none";

function alttagoff() {
    document.all["alttagDiv"].innerHTML = '';
    over.display = "none";
	moveable = 0;
}

function alttag(statustext) {
    document.all["alttagDiv"].innerHTML = statustext;
    over.display = "block";
	if (ns6) moveDivTo(over,e.pageX + 10,e.pageY + 10);
	if (ie4) moveDivTo(over,event.x + 10,event.y + 10);
	if (ie5) moveDivTo(over,event.x + document.body.scrollLeft + 10,event.y + document.body.scrollTop + 10);
	moveable = 1;
}

function mouseMove(e) {
  if (moveable == 1) {
	if (ns6) moveDivTo(over,e.pageX + 10,e.pageY + 10);
	if (ie4) moveDivTo(over,event.x + 10,event.y + 10);
	if (ie5) moveDivTo(over,event.x + document.body.scrollLeft + 10,event.y + document.body.scrollTop + 10);
  }
}

function moveDivTo(obj,xL,yL) {
	if (ie4) {
		obj.left = (ie4 ? xL + 'px' : xL);
		obj.top = (ie4 ? yL + 'px' : yL);
	} else if (ns6) {
		obj.style.left = xL + "px";
		obj.style.top = yL+ "px";
	}
}