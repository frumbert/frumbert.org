var cellCounter = 0;
var msgCounter = 1;
var fsArray = new Array();

// Width of characters 32 through 126
var ComicSans10Bold = new Array(6, 3, 6, 11, 9, 11, 9, 6, 5, 5, 7, 8, 6, 8, 6, 7, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 6, 6, 8, 8, 8, 7, 12, 10, 8, 8, 9, 8, 8, 9, 10, 7, 9, 8, 7, 11, 11, 10, 7, 11, 8, 9, 9, 10, 9, 14, 9, 8, 9, 5, 7, 5, 8, 8, 7, 7, 8, 7, 8, 7, 7, 7, 8, 4, 5, 7, 4, 10, 7, 7, 7, 7, 6, 6, 6, 7, 6, 9, 8, 7, 7, 5, 5, 5, 8);
var HyphenBefore = "hlmnrsHLMNRS1234567890";

document.onload = setupWidths();

function getInnerHt() {
	return document.documentElement.offsetHeight;
}
function getInnerWd() {
	return document.documentElement.offsetWidth;
}

function innerHt() {
	if (document.all)
		return top.document.body.clientHeight;
	else
		return top.window.innerHeight;
}

function innerWd() {
	if (document.all)
		return top.document.body.clientWidth;
	else
		return top.window.innerWidth;
}

function getField(vData, vField) {
	if (typeof(vData) == 'undefined') return '';
	var ArX, ArY, i, ArO;
	if (vData.indexOf("*~-") == -1) return '';
	ArX = vData.split("*~-");
	for (i=0; i<ArX.length; i++) {
		ArY = ArX[i].split("-~*");
		if (ArY[0].toLowerCase() == vField.toLowerCase()) return ArY[1];
	}
}

//
// GLOBALS
// 
var glbMaxWidth;
var glbTableWidth = 300;
var glbTableCells = 3;
var lineWidth = 0;
var cFrame = parent.chat;
var intScrollValue = 0;
var myValue = 0;
var k = 0, t; // global counters for cell thingamy
var isInitable = true;

function setupWidths() {
	try { // An exception might occur due to cross-frame scripting
		var foo = top.frames,s='',xtra=0;
		for (i=0;i<foo.length;i++) {
			if(i>0)s+=',';
			s+=foo[i].name;
		}
		if (s!='chatbar,chatframe') {
			if (top.document.getElementsByTagName("IFRAME").length > 0) {
				xtra = 0; // Running in an iframe, probably Jetty or custom f/w
			} else {
				xtra = 175; // Running in a frameset, do I need to calc this?
			}
		}
	} catch(e) {
		var xtra = 0;
	}
	var wd1 = (innerWd() - 170) - xtra;
	var wd2 = (parseInt(wd1 / 300)) - 1;
	if (!document.all) wd2 = 1; // until i can work out how to make netscape properly report the inner width
	if (wd2 < 1) wd2 = 1; // Controls the minimum number of tables across: value = (number_of_tables - 1)
	wd = wd2 * 300;
	glbMaxWidth = wd;
}

function domInsert(html) {
	my_break = cFrame.document.createElement( "BR" );
	my_break.setAttribute( "clear","all" );
	my_div = cFrame.document.createElement( "DIV" );
	my_div.innerHTML = html;
	my_body = cFrame.document.getElementById( "comicchat" );
	my_body.appendChild(my_break); // before
	my_body.appendChild(my_div);
	my_body.appendChild(my_break); // after
	lineWidth = 0;
	k = 0;
}

function my_domTable() {
	lineWidth += 300; // This table will take up this much space
	my_break = cFrame.document.createElement( "BR" );
	my_break.setAttribute( "clear","all" );
	my_table = cFrame.document.createElement( "TABLE" );
	my_tableBody = cFrame.document.createElement( "TBODY" );
	my_currentRow = cFrame.document.createElement( "TR" );
	my_currentCell = cFrame.document.createElement( "TD" );
	my_currentText = cFrame.document.createTextNode( " " );
	my_currentCell.appendChild( my_currentText );
	my_currentRow.appendChild( my_currentCell );
	my_tableBody.appendChild( my_currentRow );
	my_table.appendChild( my_tableBody );
	my_body = parent.chat.document.getElementById( "comicchat" );
	if (!my_body) {
		// Maybe the frame isn't properly initialised?
		extInit();
		parent.chat.document.clear();
		parent.chat.document.open();
		parent.chat.document.write('<BODY><DIV ID="comicchat"></DIV></BODY>');
		parent.chat.document.close();
		my_body = parent.chat.document.getElementById( "comicchat" );
	}
	my_body.appendChild( my_table );
	if (lineWidth > glbMaxWidth) {
		lineWidth = 0; // reset line width
		my_body.appendChild(my_break);
	}
	my_table.setAttribute( "id","table" + my_domTable.arguments[0] );
	my_table.setAttribute( "border","0" );
	my_table.setAttribute( "cellPadding","0" );
	my_table.setAttribute( "cellSpacing","0" );
	my_table.setAttribute( "align","left" );
	my_table.setAttribute( "width",glbTableWidth );
	my_table.setAttribute( "height","220" );
	if (cellBg) my_table.setAttribute( "background",cellBg );
	this.add	        = my_domTable_add;
	this.my_tablebody	= my_tableBody;
	this.col			= 0;
	this.obj			= cFrame.document.getElementById("table" + my_domTable.arguments[0]); // this
}

function my_domTable_add() {
	my_current_cell = cFrame.document.createElement( "TD" );
	my_current_cell.setAttribute( "vAlign","bottom" );
	my_current_cell.setAttribute( "align","center" );
	my_current_cell.setAttribute( "width",(glbTableWidth / glbTableCells) );
	my_current_cell.setAttribute( "height","220" );
	my_current_cell.setAttribute( "id","td" + my_domTable_add.arguments[1] );
	my_current_cell.innerHTML = my_domTable_add.arguments[0];
	currentTR = this.my_tablebody.getElementsByTagName("TR").item(0);
	if (this.col == 0) { // When the table object is created, it has an empty cell. remove it.
		currentTR = this.my_tablebody.getElementsByTagName("TR").item(0);
		currentTR.removeChild(currentTR.getElementsByTagName("TD").item(0));
	}
	currentTR.appendChild(my_current_cell);
	this.col++;
}

function drawBalloon(n,id) {
	var str = "", rnd = Math.random(), tCol = "";
	rnd = (rnd * 10);
	var isModerator = (getField(n,"Moderator") == "yes"); // Means "am I a moderator"
	var isDeletable = (getField(n,"ChatDel") == "yes"); // Means "can I delete?"
	var sTailXtras = "";
	var strMap = "";
	var msgId = getField(n, "msgid"+id);
	var sText = getField(n, "text"+id);

	if (sText.toLowerCase().indexOf("sounds are now disabled")>-1) {
		parent.message.toggleSounds(false);
	} else 	if (sText.toLowerCase().indexOf("sounds are now enabled")>-1) {
		parent.message.toggleSounds(true);
	}


	sText = sText.replace(/\*\*\* censored \*\*\*/, "@%#*@ !?");
	var iType = getField(n,"bubble"+id);
	// var bString = new FastString();

	// Should pick up any bubbles that retain the users name as part of teh text and remove it
	if (sText.indexOf("> ") !=-1) {
		sText = sText.substring(sText.indexOf("> ")+1, sText.length);
	}

	if (rnd < 5) sTailXtras = "Alt"; // Tail on left or right
	if (isDeletable) sTailXtras += "_D"; // Has delete button
	if (getField(n,"avatar"+id).indexOf("{")==-1) iType = "1";

	// sText += "</font>";

	if (iType == "4") {
		if (isModerator) {
			if (sTailXtras.indexOf("_")==-1) sTailXtras += "_"
			sTailXtras += "M";
			if (isDeletable) {
				str += "<map name='WS_"+msgId+"'><area href='javascript:parent.engine.doDelete("+msgId+");' shape='rect' coords='4,11,18,23'><area href='javascript:parent.engine.doPromote("+msgId+")' shape='rect' coords='77,11,91,23'></map>"
			} else {
				str += "<map name='WS_"+msgId+"'><area href='javascript:parent.engine.doPromote("+msgId+")' shape='rect' coords='77,11,91,23'></map>"
			}
		} else if (isDeletable) {
			str += "<map name='WS_"+msgId+"'><area href='javascript:parent.engine.doDelete("+msgId+");' shape='rect' coords='4,11,18,23'></map>"
		}
		if (document.all) {
			str += "<div style='z-index:3;width:96px;'>";
			str += "<img src='/toolbox/chat/images/WhisperTop.gif' width='96' height='15' alt='" + getField(n,"user"+id) + " whispers " + getField(n, "WhisperTo"+id) + "'><br>";
		} else {
			str += "<div style='z-index:3;width:96px;' title='" + getField(n,"user"+id) + " whispers " + getField(n, "WhisperTo"+id) + "'>";
			str += "<img src='/toolbox/chat/images/WhisperTop.gif' width='96' height='15' alt=''><br>";
		}
		str += "<div style='background-image:url(/toolbox/chat/images/WhisperMiddle.gif);background-repeat:repeat-y;padding:0 3px 0 3px;text-align:center;font-family:Comic Sans MS;font-size:10pt;font-weight:bold;line-height:110%;'>"
		str += sText + "</div>"
		str += "<img src='/toolbox/chat/images/WhisperBottom"+sTailXtras+".gif' width='96' height='26' border='0'"
		if (isModerator || isDeletable) str += " usemap='#WS_"+msgId+"'"
		str += "></div>";
	} else if (iType == "3") {
		if (isDeletable) {
			str += "<map name='YS_"+msgId+"'><area href='javascript:parent.engine.doDelete("+msgId+");' shape='rect' coords='4,6,18,18'></map>";
		}
		str += "<div style='z-index:3;width:96px;'>";
		str += "<img src='/toolbox/chat/images/ShoutTop.gif' width='96' height='5' alt='' border='0'><br>";
		str += "<div style='background-image:url(/toolbox/chat/images/ShoutMiddle.gif);background-repeat:repeat-y;padding:0 3px 0 3px;text-align:center;font-family:Comic Sans MS;font-size:10pt;font-weight:bold;line-height:110%;'>"
		str += sText.toUpperCase() + "</div>";
		str += "<img src='/toolbox/chat/images/ShoutBottom"+sTailXtras+".gif' width='96' height='21' border='0'"
		if (isDeletable) str += " usemap='#YS_"+msgId+"'"
		str += "></div>";
	} else if (iType == "1") {
		if (isDeletable) {
			str += "<map name='FS_"+msgId+"'><area href='javascript:parent.engine.doDelete("+msgId+");' shape='rect' coords='3, 0, 20, 12'></map>";
		}
		str += "<div style='z-index:3;width:96px;'>";
		str += "<img src='/toolbox/chat/images/SystemTop.gif' width='96' height='10' border='0' alt=''><br>";
		str += "<div style='background-image:url(/toolbox/chat/images/SystemMiddle.gif);background-repeat:repeat-y;text-align:center;font-family:sans-serif;font-size:10pt;line-height:110%;"
		if ((sText.toLowerCase().indexOf("room") > -1) || (sText.toLowerCase().indexOf("exits") > -1)) { // not that smart
			str += "color:#993333;font-style:italic;padding:6px 6px 6px 6px;'>";
		} else {
			str += "color:#336699;padding:0 6px 0 6px;'>";
		}
		str += sText + "</div>";
		if (isDeletable) {
			str += "<img src='/toolbox/chat/images/SystemBottom_D.gif' width='96' height='13' border='0' alt='' usemap='#FS_"+msgId+"'>"
		} else {
			str += "<img src='/toolbox/chat/images/SystemBottom.gif' width='96' height='7' border='0' alt=''>";
		}
		str += "</div>";
	} else {
		if (isDeletable) {
			str += "<map name='TS_"+msgId+"'><area href='javascript:parent.engine.doDelete("+msgId+");' shape='rect' coords='4,8,18,28'></map>";
		}
		str += "<div style='z-index:3;width:96px;'>"
		str += "<img src='/toolbox/chat/images/BubbleTop.gif' width='96' height='6' border='0' alt=''><br>"
		str += "<div style='background-image:url(/toolbox/chat/images/BubbleMiddle.gif);background-repeat:repeat-y;padding:0 3px 3px 3px;text-align:center;font-family:Comic Sans MS;font-size:10pt;font-weight:bold;line-height:110%;'>"
		str += sText + "</div>";
		str += "<img src='/toolbox/chat/images/BubbleBottom"+sTailXtras+".gif' width='96' height='23' border='0' alt=''"
		if (isDeletable) str += " usemap='#TS_"+msgId+"'";
		str += ">";
		str += "</div>";
	}
	return str;
	if (debug) debug()
}

function doDelete(n) {
	parent.progress.document.location = "/toolbox/chat/chatact.asp?RoomId=" + RoomId + "&DelMsg=" + n;
}

function doPromote(n) {
	parent.progress.document.location = "/toolbox/chat/chatact.asp?RoomId=" + RoomId + "&MsgId=" + n + "&amp;action=promote";
}

function extInit() { // resets position and count (globals)
	k = 0;
	lineWidth = 0;
}

function pushMsg(n,bForceScroll) {
	var s = "", cnt=1;
	el = parent.chat.document.getElementById( "comicchat" );
	elB = parent.chat.document.body; // Mozilla doesn't seem to like this :(
	if (getField(n, "clearRoom") == "yes") {
		el.innerHTML = "";
		lineWidth = 0;
		k = 0;
	}
	if (getField(n, "chatDel") == "yes") {
		if (isInitable) {
			el.innerHTML = "";
			lineWidth = 0;
			k = 0;
		}
		isInitable = false;
	}
	if (getField(n, "chatDel") != "yes") isInitable = true
	reInitPane = getField(n, "initPane");
	if ( reInitPane == "yes" ) {
		parent.engine.extInit();
		parent.chat.document.clear();
		parent.chat.document.open();
		parent.chat.document.write('<BODY><DIV ID="comicchat"></DIV></BODY>');
		parent.chat.document.close();
	}
	msgs = parseInt(getField(n, "intMsgs"));
	if (msgs>0) {
		for (cnt = msgs; cnt>0; cnt--) { // (cnt=1; cnt<msgs+1; cnt++)
			if (cnt != 'undefined') {
				var sysmessage = getField(n, "sysmessage"+cnt);
				var theText = getField(n,"text"+cnt);
				if (theText.indexOf('<font color="DarkRed">Room background has been set to ') > -1) {
					cellBg = theText.substring(54,theText.indexOf("</font>"));
				} else {
	        		id = getField(n, "msgid"+cnt);
					if (getField(n, "special"+cnt) == "yes") {
						t = new my_domTable(k);
						t.obj.style.border = "1px solid black";
						t.obj.style.margin = "1px";
						t.obj.style.overflow = "hidden";
						var theImage = getField(n,"text"+cnt);
						if (theImage.toLowerCase().indexOf("imgthumbnail.asp") == -1) {
							// image fits, don't link it, just add it.
							t.add(theImage);
						} else {
							// Grab the original source and link to it in a blank window
							theUrl = theImage.substring(theImage.toLowerCase().indexOf("imgthumbnail.asp")+21, theImage.indexOf("&"));
							theLink = "<a href='" + theUrl + "' target='_blank'>" + theImage + "</a>";
							t.add(theLink);
						}
						cEl = t.obj.getElementsByTagName("TD");
						cEl.item(cEl.length-1).style.verticalAlign = "middle";
						cEl.item(cEl.length-1).style.textAlign = "center";
						cEl.item(cEl.length-1).style.width = "300px";
						if (k%3==0) {
						} else {
							// increment counter so next message is drawn in another table
							while (k%3>0) k++;
						}
					} else {
						if (k%3==0) {
							t = new my_domTable(k);
							t.obj.style.border = "1px solid black";
							t.obj.style.margin = "1px";
							t.obj.style.overflow = "hidden";
						}
	    				speechBubble = drawBalloon(n,cnt);
	           			if (getField(n,"avatar"+cnt).indexOf("{")!=-1) {
	    					avatarImage = "<img src='" + getImage(n,cnt) + "' border='0' title='" + getField(n,"user"+cnt) + " (" + emoteText(n,cnt) +") \nSent at " + getField(n, "date"+cnt) + "' width='100' height'110'>";
	    				} else {
	    					avatarImage = "";
	    				}
	    				if (avatarImage > "") {
							// if (getField(n,"text"+cnt).length > 62) r = 30;
							// else r = 20;
							r = 20;
	    					t.add("<div style='z-index:20;position:relative;bottom:-" + r + "px;'>" + speechBubble + "</div><div style='z-index:10;position:relative;bottom:0px;'>" + avatarImage + "</div>",id);
	    				} else {
	    					t.add(speechBubble,id);
							cEl = t.obj.getElementsByTagName("TD");
							cEl.item(cEl.length-1).style.verticalAlign = "middle";
	    				}
		   				k++; // iterate counter that lets us know if we need to add cells or a new table.
					} // Special
				} // Background change
			} // has a message
    	} // next
	} // if messages
	if (document.all) { // Maintaing position in Moz works fine like this in one frame.. this fails tho :(
		var intScrollValue = elB.scrollHeight - elB.offsetHeight;
		if (elB.myValue-elB.scrollTop < 5) elB.scrollTop = intScrollValue + 10;
		elB.myValue = (intScrollValue < 0) ? 0 : intScrollValue;
	} else {
		elB.scrollTop = elB.scrollHeight;
	} // ie scrolling thing
	if (bForceScroll) elB.scrollTop = 99999;
	var userTable = getField(n, "userTable");
	var pollTable = getField(n, "pollTable");
	var timeCell = getField(n, "txtTime");
	var txtCellBg = getField(n, "txtCellBg");
	var txtSound = getField(n, "txtSound");
	var intMedia = getField(n, "intMedia");
	var txtComicString = getField(n, "ComicString");
	var txtDebugString = getField(n, "DebugString");
	if (timeCell > "")  parent.users.document.getElementById("chattime").innerHTML  = timeCell;
	if (userTable > "") parent.users.document.getElementById("chatusers").innerHTML = userTable;
	if (pollTable > "") parent.users.document.getElementById("chatpoll").innerHTML  = pollTable;
 	if (txtDebugString > "") {
		parent.users.document.getElementById("chatdebug").innerHTML = txtDebugString;
	} else {
		parent.users.document.getElementById("chatdebug").innerHTML = '';
	}
	if (txtCellBg > "") cellBg = txtCellBg; // Update var holding cell background image, next table will have it :)
	if (txtSound > "") playsound(txtSound);
	if (txtComicString == "disabled") parent.message.forceRestart(txtComicString, "C");
	setTimeout('FixWidth()',100); // Makes IE force the user table width to full body width if scrollbar isn't needed
}

function FixWidth() {
	parent.users.FixWidth();
}

function emoteText(n,id) {
	switch (parseInt(getField(n,"emote"+id))) {
		case 2: return "Angry";
		case 3: return "Bored";
		case 4: return "Happy";
		case 5: return "Laughing";
		case 6: return "Neutral";
		case 7: return "Sad";
		case 8: return "Scared";
		case 9: return "Shouting";
		case 10: return "Shy";
		case 11: return "Pointing at self";
		case 12: return "Pointing at another";
		case 13: return "Waving";
	}
}

function playsound(f) {
	document.getElementById("tbChatBgSound").innerHTML = "<embed width='0' height='0' src='/toolbox/sounds/" + f + "' loop='false' autostart='true'></embed>";
}

function getTimeInSeconds() {
	var dt = new Date();
	gt = dt.getTime();
	gt = gt + dt.getTimezoneOffset();
	dt.setTime(gt);
	return ((dt.getHours()*60)*60) + (dt.getMinutes()*60) + dt.getSeconds()
}

var initTime = getTimeInSeconds();

function resetInitTime() {
	initTime = getTimeInSeconds();
}

function initCleanup() {
	// delay start for around for about 2 minutes then start cleaning up
	if ((getTimeInSeconds() - initTime) < 20) {
		setTimeout('initCleanup()',10001);
	} else {
		Cleanup();
	}
}

function Cleanup() {
	var chatHeight = parent.chat.document.documentElement.offsetHeight;
	arbShowRows = Math.ceil(chatHeight / 220);						// need to know how many "high" we can have 
	var cols = (glbMaxWidth / glbTableWidth) + 1;
	var maxLength = cols * arbShowRows;								// maximum we can have "on screen"
	if (parent.chat.document.getElementById("comicchat")) {
		var ccTables = cFrame.document.getElementsByTagName("TABLE");
		var currLength = ccTables.length;							// count of individual tables on the page
		var rows = Math.ceil(currLength / cols);					// whole number of rows, partial or not
		var diff = rows - maxLength;								// how many are "not" shown; e.g. how many rows to remove
		var tablesToRemove = diff * cols;							// number of tables to remove
		if (tablesToRemove>0) {
			for (var i=0;i<tablesToRemove;i++) {
				var ref = ccTables.item(0);
				ref.removeNode(true);
			}
		}
		setTimeout('Cleanup()',10100);								// Check again in a few second
	}
}