var op = /opera 5|opera\/5/i.test(navigator.userAgent);
var ie = !op && /msie/i.test(navigator.userAgent);
var mz = !op && /mozilla\/5/i.test(navigator.userAgent);

if (ie && window.attachEvent) {
	window.attachEvent("onload", function () {
		var scrollBorderColor	=	"#9999aa"; // rgb(120,172,255)
		var scrollFaceColor		=	"#eeeeff"; // rgb(234,242,255)
		with (document.body.style) {
			scrollbarDarkShadowColor	=	scrollBorderColor;
			scrollbar3dLightColor		=	scrollBorderColor;
			scrollbarArrowColor			=	"black";
			scrollbarBaseColor			=	scrollFaceColor;
			scrollbarFaceColor			=	scrollFaceColor;
			scrollbarHighlightColor		=	scrollFaceColor;
			scrollbarShadowColor		=	scrollFaceColor;
			scrollbarTrackColor			=	"white";
		}
	});
}
