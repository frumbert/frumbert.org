Basic Image Mapper
------------------



email: frumbert@hotmail.com
web: http://members.xoom.com/frumbert/programming/



Basic Image Mapper is just that - a HTML image mapping program that creates image maps. In the current version, you can only make Rectangular areas on your images, but a future version will contain the other supported shapes.



Features:
-Easy to use interface
-Lack of the unneccesary functions of comemercial or shareware image mappers
-Support for target frame names
-Edit functions for HTML code



Planned in Next Release:
-Crosshair for better positioning
-Fix for that size bug (see below)
-Circle and/or Polygon support
-Undo support for drawing tools
-Save As saves both Image and HTML in directory



Known Issues ver 1.0.1:
-Sometimes crashes if the image size is less than 63 pixels accross or down (don't try it, just take my word for it)
-Doesn't show scroll bars on low-res screens
